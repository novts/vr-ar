﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstConsoleApp
{
    /// <summary>
    /// First Console App lecture code
    /// </summary>
    class Program
    {
        /// <summary>
        /// Prints a message
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            // print supportive message
            Console.WriteLine("Hello World!");

            // Keep the console window open in debug mode.
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    }
}

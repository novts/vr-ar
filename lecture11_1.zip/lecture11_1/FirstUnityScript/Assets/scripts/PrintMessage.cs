﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Prints a message
/// </summary>
public class PrintMessage : MonoBehaviour
{
	/// <summary>
	/// Use this for initialization
	/// </summary>
	void Start()
	{
		// print supportive message
        print("Hi, n00b!");
	}
}

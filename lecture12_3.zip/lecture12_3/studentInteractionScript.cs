﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using vrCampusCourseware;

public class studentInteractionScript : MonoBehaviour {

    [Header("Courseware")]
    [SerializeField]
    TrackingDisplay leftScreen;

    [Header("Laser Pointer")]
    [SerializeField]
    Transform LaserHolderTransform;

    [SerializeField]
    Transform LaserBeamTransform;

    [SerializeField]
    Transform LaserBeamDot;

    [SerializeField]
    VRCampus.Reticle m_Reticle;

    [SerializeField]
    float maxDistance = 50.0f;

    [SerializeField] Color hlColor;

    [Header("Robots")]
    [SerializeField]
    robotScript leftRobot;

    [SerializeField]
    robotScript rightRobot;

    [SerializeField]
    LaserPistol thePistol;

    private bool enable = false;
    public void enableTeacherScripts(bool mode)
    {
        enable = mode;
    }
    switchRooms.roomType curRoom = switchRooms.roomType.Study;

    public void switchRoom(switchRooms.roomType type)
    {
        curRoom = type;
    }

    private void Awake()
    {
        laserScale = LaserBeamTransform.localScale;
        LaserBeamTransform.GetComponent<MeshRenderer>().material.color = hlColor;
        LaserBeamTransform.GetComponent<MeshRenderer>().material.SetColor("_EmissionColor", hlColor);
        LaserBeamDot.GetChild(0).GetComponent<MeshRenderer>().material.color = hlColor;
        LaserBeamDot.GetChild(0).GetComponent<MeshRenderer>().material.SetColor("_EmissionColor", hlColor);
    }

    bool laserIsOn = true;
    public void Off()
    {
        if (laserIsOn)
        {
            laserIsOn = false;
            LaserBeamDot.gameObject.SetActive(false);
            LaserBeamTransform.gameObject.SetActive(false);
        }
    }

    public void On()
    {
        if (!laserIsOn)
        {
            laserIsOn = true;
            LaserBeamDot.gameObject.SetActive(true);
            LaserBeamTransform.gameObject.SetActive(true);
        }
    }

    float curLength;
    Vector3 laserScale;
    bool butPressed = false;

    protected void Update()
    {
        if (!enable) return;

        if (curRoom != switchRooms.roomType.Interaction) return;

        //get direction of the controller
        Ray myRay = new Ray(LaserHolderTransform.position, LaserHolderTransform.forward);

        //change the laser's length depending on where it hits
        float length = maxDistance;

        RaycastHit hit;
        if (Physics.Raycast(myRay, out hit, length))
        {
            leftScreen.InteractionInfo(hit);
            length = hit.distance;
            laserScale.y = length / 2;

            curLength = length;
            LaserBeamTransform.localScale = laserScale;

            Vector3 lbdPos = LaserBeamDot.localPosition;
            lbdPos.z = curLength;
            LaserBeamDot.localPosition = lbdPos;
            lbdPos.z /= 2;
            LaserBeamTransform.localPosition = lbdPos;

            if (m_Reticle)
                m_Reticle.SetPosition(hit);

            // did we hit the robot head?
            if (Input.GetButton("VRTouchPressedRight"))
            {
                if (!butPressed)
                {
                    thePistol.fireRound();
                    butPressed = true;
                    if (hit.collider.name == "balloon_lowL")
                    {
                        if (!leftRobot.isPopped())
                        {
                            leftRobot.PopHead();
                        }
                    }
                    else
                    if (hit.collider.name == "balloon_lowR")
                    {
                        if (!rightRobot.isPopped())
                        {
                            rightRobot.PopHead();
                        }
                    }
                }
            }
            else
            {
                butPressed = false;
            }
        }
        else
        {
            butPressed = false;
            m_Reticle.SetPosition();
        }
    }

}

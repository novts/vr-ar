﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;
using vrCampusCourseware;

public class studentLocomotionScript : MonoBehaviour {

    [Header("Courseware")]
    [SerializeField]
    TrackingDisplay leftScreen;

    [Header("Laser Pointer")]
    [SerializeField] Transform LaserHolderTransform;
    [SerializeField] Transform LaserBeamTransform;
    [SerializeField] Transform LaserBeamDot;
    [SerializeField] VRCampus.Reticle m_Reticle;
    [SerializeField] float maxDistance = 50.0f;
    [SerializeField] Color hlColor;

    [Header("Grabbing")]
    [SerializeField] XRNode whichNode;
    [SerializeField] ControllerHider theController;
//    [SerializeField] Gripper theGripper;
    [SerializeField] Transform ballHolder;

    [Header("Teleporting")]
    [SerializeField] GameObject floor;
    [SerializeField] Transform envHolder;
    [SerializeField] Transform theFloorMarker;


    private bool enable = false;
    public void enableTeacherScripts(bool mode)
    {
        enable = mode;
    }

    float curLength;
    // Update is called once per frame
    Vector3 laserScale;

    bool hasPressed = false;
    bool ballGrabbed = false;
    Vector3 tpEulers = new Vector3(90, 0, 0);
    Vector3 envEulers = new Vector3(0, 0, 0);

    Vector3 lastBallPosn;
    Vector3 curBallPosn;

    Transform oldBallParent;
    switchRooms.roomType curRoom = switchRooms.roomType.Study;
    public void switchRoom(switchRooms.roomType type)
    {
        curRoom = type;
    }


    private void Awake()
    {
        laserScale = LaserBeamTransform.localScale;
        LaserBeamTransform.GetComponent<MeshRenderer>().material.color = hlColor;
        LaserBeamTransform.GetComponent<MeshRenderer>().material.SetColor("_EmissionColor", hlColor);
        LaserBeamDot.GetChild(0).GetComponent<MeshRenderer>().material.color = hlColor;
        LaserBeamDot.GetChild(0).GetComponent<MeshRenderer>().material.SetColor("_EmissionColor", hlColor);
    }

    private void FixedUpdate()
    {
        if (ballGrabbed)
        {
            lastBallPosn = curBallPosn;
            curBallPosn = ballHolder.position;
            leftScreen.LocomotionBallInfo(curBallPosn, (curBallPosn - lastBallPosn) * Time.fixedDeltaTime);
        }
    }

    bool gripClosed = false;
    bool gripVisible = false;
    private void Update()
    {
        if (!enable) return;
        if (curRoom != switchRooms.roomType.Locomotion) return;

        if (hasPressed)
        {
            // user pressed the button and now we're waiting to rotate and then let go
            if (!Input.GetButton("VRTouchPressedRight"))
            {
                hasPressed = false;

//                gripClosed = false;
//                theController.OpenGripper(true);

                Vector3 v = theFloorMarker.position;
                v.y = envHolder.position.y;
                envHolder.position = v;
                envEulers.y = tpEulers.y;
                envHolder.rotation = Quaternion.Euler(envEulers);
            }
            else
            {
                // still pressing trigger.. rotate per horizontal axis
                Vector3 hitPos;

                //change the laser's length depending on where it hits
                float length = maxDistance;

                RaycastHit hit;

                //get direction of the controller
                Ray myRay = new Ray(LaserHolderTransform.position, LaserHolderTransform.forward);
                if (Physics.Raycast(myRay, out hit, length))
                {
                    length = hit.distance;

                    laserScale.y = length / 2;

                    curLength = length;
                    LaserBeamTransform.localScale = laserScale;

                    Vector3 lbdPos = LaserBeamDot.localPosition;
                    lbdPos.z = curLength;
                    LaserBeamDot.localPosition = lbdPos;
                    lbdPos.z /= 2;
                    LaserBeamTransform.localPosition = lbdPos;

                    if (hit.collider.gameObject == floor)
                    {
                        hitPos = hit.point;
                        theFloorMarker.position = hitPos;
                        float xRot = Input.GetAxis("VRTPRightHorizontal") * 180;
                        tpEulers.y = xRot;
                        theFloorMarker.rotation = Quaternion.Euler(tpEulers);

                        leftScreen.LocomotionTPInfo(hitPos, xRot);

                        if (m_Reticle)
                        {
                            m_Reticle.SetPosition(hit);
                            m_Reticle.SetOn(true);
                        }
                    }
                    else
                    {
                        m_Reticle.SetOn(false);
                        m_Reticle.SetPosition();
                    }
                }
                else
                {
                    m_Reticle.SetOn(false);
                    m_Reticle.SetPosition();
                }
            }
        }
        else
        if (ballGrabbed)
        {
            if (Input.GetAxis("VRRightTriggerAxis") < 0.4f)
            {
                // release the ball
                ballGrabbed = false;

                // unparent the ball from the controller
                ballHolder.parent = oldBallParent;
                ballHolder.GetComponent<Rigidbody>().isKinematic = false;
//                ballHolder.GetComponent<Rigidbody>().velocity = (curBallPosn - lastBallPosn) / Time.fixedDeltaTime;

                gripVisible = false;
                theController.ShowGripper(false);

                // disable the laser
                LaserBeamTransform.gameObject.SetActive(true);
                LaserBeamDot.gameObject.SetActive(true);
            }
        }
        else
        {

            // check to see if we're near the ball first

            float dist = Mathf.Sqrt((LaserHolderTransform.position - ballHolder.position).sqrMagnitude);
            if (dist < 0.75f)
            {
                gripVisible = true;
                theController.ShowGripper(true);

                if (Input.GetAxis("VRRightTriggerAxis") > 0.6f)
                {
//                    Collider[] objs = Physics.OverlapSphere(LaserHolderTransform.position, 0.2f, 16);
                    /*
                    if (!gripClosed)
                    {
                        gripClosed = true;
                        theController.OpenGripper(false);
                    }
                    */

                    // pick up the ball
                    ballGrabbed = true;

                    // reparent the ball to the controller
                    ballHolder.GetComponent<Rigidbody>().isKinematic = true;
                    oldBallParent = ballHolder.parent;
                    ballHolder.parent = theController.transform;
                    ballHolder.localPosition = theController.GetGripperOffset();
                    ballHolder.localRotation = theController.GetGripperRotation();

                    // disable the laser
                    LaserBeamTransform.gameObject.SetActive(false);
                    LaserBeamDot.gameObject.SetActive(false); 
                }
            }
            else
            {
                gripVisible = false;
                theController.ShowGripper(false);
            }

            if (!ballGrabbed)
            {
                Vector3 hitPos;

                //change the laser's length depending on where it hits
                float length = maxDistance;

                RaycastHit hit;

                //get direction of the controller
                Ray myRay = new Ray(LaserHolderTransform.position, LaserHolderTransform.forward);
                if (Physics.Raycast(myRay, out hit, length))
                {
                    leftScreen.InteractionInfo(hit);

                    length = hit.distance;

                    laserScale.y = length / 2;

                    curLength = length;
                    LaserBeamTransform.localScale = laserScale;

                    Vector3 lbdPos = LaserBeamDot.localPosition;
                    lbdPos.z = curLength;
                    LaserBeamDot.localPosition = lbdPos;
                    lbdPos.z /= 2;
                    LaserBeamTransform.localPosition = lbdPos;

                    if (Input.GetButton("VRTouchPressedRight") && hit.collider.gameObject == floor)
                    {
                        hitPos = hit.point;
                        theFloorMarker.position = hitPos;
                        hasPressed = true;
                        if (m_Reticle)
                            m_Reticle.SetPosition(hit);
                    }
                    else
                        m_Reticle.SetPosition();
                }
                else
                {
                    leftScreen.InteractionInfo();
                    m_Reticle.SetPosition();
                }
            }
        }
    }
}
